# Change Log

## 0.3.0 (December 31, 2016)

- Feature: Support config the path(absolute or relative) to save image.(@ysknkd in #4)

## 0.2.0 (November 13, 2016)

- Feature: Add linux support by xclip
- Feature: Support use the selected text as the image name

## 0.1.0 (November 12, 2016)

- Feature: Add windows support by powershell(@kivle in #2)

## 0.0.1

- Finish first publish. Only support macos.