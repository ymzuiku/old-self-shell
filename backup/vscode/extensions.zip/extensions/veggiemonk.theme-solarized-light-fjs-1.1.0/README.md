# Solarized Light Functional JavaScript Theme
![Screenshot](https://github.com/veggiemonk/theme-solarized-light-fjs/raw/master/Screenshot_01.png)

All functions in the code clearly stand out with the light theme.

Originally tailored for JavaScript but it should work 
fine with other languages too.

Share your thoughts/suggestions/comments about it 
on twitter `@veggiemonk` or on github.


# How to customize to your taste

Use this app `http://tmtheme-editor.herokuapp.com/`

You can even load it directly from the url.

Ask if you need any assistance

**Enjoy!**

## Credits

It was not build from scratch, 
it was imported with `yo code` ( [see instructions here](https://code.visualstudio.com/docs/tools/yocode) ) 
from `http://colorsublime.com/theme/Solarized-light`