# Solarized-light

A theme based on the [Solarized-light TextMate Theme](http://colorsublime.com/theme/Solarized-light).


## Screenshot
![](https://raw.githubusercontent.com/gerane/VSCodeThemes/master/gerane.Theme-Solarized-light/screenshot.png).


## More Information
* [Visual Studio Marketplace](https://marketplace.visualstudio.com/items/gerane.Theme-Solarized-light).
* [GitHub repository](https://github.com/gerane/VSCodeThemes).
