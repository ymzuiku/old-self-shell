## Environment data
VS Code version:  
Python Extension version:  
Python Version:   
OS and version:    

## Actual behavior

## Expected  behavior

## Steps to reproduce:  
-  
-  

## Settings  
Your launch.json (if dealing with debugger issues):  
```json
```   
Your settings.json:   
```json
```   
## Logs
Output from ```Python``` output panel  
```
```   
Output from ```Console window``` (Help->Developer Tools menu)
```
```
