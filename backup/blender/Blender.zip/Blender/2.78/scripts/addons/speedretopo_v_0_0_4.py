'''
Copyright (C) 2016 Cedric lepiller
pitiwazou@gmail.com

Created by Cedric lepiller

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

bl_info = {
    "name": "SpeedRetopo",
    "description": "Addon for retopology",
    "author": "Cedric Lepiller, EWOC for Laprelax, Lapineige for Automirror",
    "version": (0, 0, 4),
    "blender": (2, 77, 3),
    "location": "View3D",
    "warning": "This addon is still in development.",
    "wiki_url": "",
    "category": "Object" }
    


import bpy
import bmesh
from mathutils import *
import math
from bpy.types import AddonPreferences, PropertyGroup
from bpy.types import Menu, Header  
from bpy.props import (StringProperty, 
                       BoolProperty, 
                       FloatVectorProperty,
                       FloatProperty,
                       EnumProperty,
                       IntProperty)


# -----------------------------------------------------------------------------
#    Funtions
# ----------------------------------------------------------------------------- 
bpy.types.WindowManager.ref_obj = bpy.props.StringProperty()

# -----------------------------------------------------------------------------
#    Setup Retopo
# ----------------------------------------------------------------------------- 

# Setup Retopo
class CreateSpeedRetopo(bpy.types.Operator):
    bl_idname = "object.create_speed_retopo"
    bl_label = "Create Speed Retopo"
    bl_description = "Create Speed Retopo"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        
        context.window_manager.ref_obj = context.active_object.name 
        ref_obj = bpy.context.window_manager.ref_obj 
                   
        #Prepare Grease Pencil
        bpy.context.scene.tool_settings.grease_pencil_source = 'OBJECT'
        bpy.context.scene.tool_settings.gpencil_stroke_placement_view3d = 'SURFACE'
        
        #Add snap
        bpy.context.scene.tool_settings.use_snap = True
        bpy.context.scene.tool_settings.snap_element = 'FACE'
        
        #Create Empty mesh
        bpy.ops.mesh.primitive_plane_add(radius=1, view_align=False, enter_editmode=False)
        bpy.context.active_object.name= "Retopo_Mesh"
        bpy.ops.object.mode_set(mode = 'EDIT')
        bpy.ops.mesh.delete(type='VERT')    
        bpy.ops.object.mode_set(mode = 'OBJECT')  
        
        #Prepare shading
        bpy.context.object.show_x_ray = True
        bpy.context.space_data.show_occlude_wire = True
        
        #Add Mirror
        bpy.ops.object.modifier_add(type='MIRROR')
        bpy.context.object.modifiers["Mirror"].use_x = True
        bpy.context.object.modifiers["Mirror"].use_clip = True
        bpy.context.object.modifiers["Mirror"].use_mirror_merge = True
        bpy.context.object.modifiers["Mirror"].show_on_cage = True
        
        #Add Shrinkwrap
        bpy.ops.object.modifier_add(type='SHRINKWRAP')
        bpy.context.object.modifiers["Shrinkwrap"].target = bpy.data.objects[ref_obj]
        bpy.context.object.modifiers["Shrinkwrap"].show_on_cage = True
        bpy.ops.object.modifier_move_up(modifier="Shrinkwrap")
        
        bpy.ops.object.mode_set(mode = 'EDIT')
        return {"FINISHED"}

# -----------------------------------------------------------------------------
#    Align to X
# ----------------------------------------------------------------------------- 

#Align to X
class AlignToX(bpy.types.Operator):  
    bl_idname = "object.align2x"  
    bl_label = "Align To X"  
    bl_options = {'REGISTER', 'UNDO'}
  
    def execute(self, context):
        bpy.ops.object.mode_set(mode = 'OBJECT')
        bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

        for vert in bpy.context.object.data.vertices:
            if vert.select: 
                vert.co[0] = 0
        bpy.ops.object.editmode_toggle() 
        return {'FINISHED'} 


# -----------------------------------------------------------------------------
#    Mirror
# -----------------------------------------------------------------------------  
    
#Apply Mirror
class ApplyMirror(bpy.types.Operator):  
    bl_idname = "apply.mirror"  
    bl_label = "Apply Mirror"  
    bl_options = {'REGISTER', 'UNDO'}
  
    def execute(self, context):
        if bpy.context.object.mode == "OBJECT":
            bpy.ops.object.modifier_apply(apply_as='DATA', modifier="Mirror")

            
        elif bpy.context.object.mode == "EDIT":
            bpy.ops.object.mode_set(mode = 'OBJECT')
            bpy.ops.object.modifier_apply(apply_as='DATA', modifier="Mirror")
            bpy.ops.object.mode_set(mode = 'EDIT')
        
        return {'FINISHED'} 

#Remove
class RemoveMirror(bpy.types.Operator):
    bl_idname = "object.remove_mirror"
    bl_label = "Remove Mirror"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        bpy.ops.object.modifier_remove(modifier="Mirror")
        return {"FINISHED"}
            
#Mirror Clipping
class MirrorClipping(bpy.types.Operator):
    bl_idname = "object.mirrorclipping"
    bl_label = "Mirror Clipping"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        layout = self.layout 
        
        bpy.context.object.modifiers["Mirror"].use_clip = not       bpy.context.object.modifiers["Mirror"].use_clip
        return {'FINISHED'} 
    
#Mirror On/Off
class MirrorOnOff(bpy.types.Operator):
    bl_idname = "object.mirroronoff"
    bl_label = "Mirror On/Off"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        layout = self.layout 
        
        bpy.context.object.modifiers["Mirror"].show_viewport = not bpy.context.object.modifiers["Mirror"].show_viewport
        return {'FINISHED'}   
    
# -----------------------------------------------------------------------------
#    Shrinkwrap
# -----------------------------------------------------------------------------  

#Apply Shrinkwrap
class ApplyShrinkwrap(bpy.types.Operator):  
    bl_idname = "apply.shrinkwrap"  
    bl_label = "Apply Shrinkwrap"  
    bl_options = {'REGISTER', 'UNDO'}
  
    def execute(self, context):
        if bpy.context.object.mode == "OBJECT":
            bpy.ops.object.modifier_apply(apply_as='DATA', modifier="Shrinkwrap")

        elif bpy.context.object.mode == "EDIT":
            bpy.ops.object.mode_set(mode = 'OBJECT')
            bpy.ops.object.modifier_apply(apply_as='DATA', modifier="Shrinkwrap")
            bpy.ops.object.mode_set(mode = 'EDIT')
        
        return {'FINISHED'} 

#Add Shrinkwrap
class AddShrinkwrap(bpy.types.Operator):
    bl_idname = "object.add_shrinkwrap"
    bl_label = "Add Shrinkwrap"
    bl_description = ""
    bl_options = {"REGISTER", 'UNDO'}

    def execute(self, context):
        ref_obj = bpy.context.window_manager.ref_obj 
    
        bpy.ops.object.modifier_add(type='SHRINKWRAP')
        bpy.context.object.modifiers["Shrinkwrap"].target = bpy.data.objects[ref_obj]
        bpy.context.object.modifiers["Shrinkwrap"].show_on_cage = True
        return {"FINISHED"}


# -----------------------------------------------------------------------------
#    LapRelax
# -----------------------------------------------------------------------------  
      
#LapRelax
class SRRelax(bpy.types.Operator):
    bl_idname = "mesh.speed_retopo_relax"
    bl_label = "Relax"
    bl_description = "Smoothing mesh keeping volume"
    bl_options = {'REGISTER', 'UNDO'}
    
    Repeat = bpy.props.IntProperty(
        name = "Repeat", 
        description = "Repeat how many times",
        default = 100,
        min = 1,
        max = 100)

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj and obj.type == 'MESH' and context.mode == 'EDIT_MESH')

    def invoke(self, context, event):
        
        # smooth #Repeat times
        for i in range(self.Repeat):
            self.do_laprelax()
        
        bpy.ops.mesh.select_all(action='DESELECT') 
        return {'FINISHED'}


    def do_laprelax(self):
    
        context = bpy.context
        region = context.region  
        area = context.area
        selobj = bpy.context.active_object
        mesh = selobj.data
        bm = bmesh.from_edit_mesh(mesh)
        bmprev = bm.copy()
        vertices = [v for v in bmprev.verts if v.select]
        
        if not vertices:
            bpy.ops.mesh.select_all(action='SELECT')
        
        for v in bmprev.verts:
            
            if v.select:
                
                tot = Vector((0, 0, 0))
                cnt = 0
                for e in v.link_edges:
                    for f in e.link_faces:
                        if not(f.select):
                            cnt = 1
                    if len(e.link_faces) == 1:
                        cnt = 1
                        break
                if cnt:
                    # dont affect border edges: they cause shrinkage
                    continue
                    
                # find Laplacian mean
                for e in v.link_edges:
                    tot += e.other_vert(v).co
                tot /= len(v.link_edges)
                
                # cancel movement in direction of vertex normal
                delta = (tot - v.co)
                if delta.length != 0:
                    ang = delta.angle(v.normal)
                    deltanor = math.cos(ang) * delta.length
                    nor = v.normal
                    nor.length = abs(deltanor)
                    bm.verts.ensure_lookup_table()
                    bm.verts[v.index].co = tot + nor
            
            
        mesh.update()
        bm.free()
        bmprev.free()
        bpy.ops.object.editmode_toggle()
        bpy.ops.object.editmode_toggle()
        
class SpaceRelax(bpy.types.Operator):
    bl_idname = "object.space_relax"
    bl_label = "Space Relax"
    bl_description = ""
    bl_options = {"REGISTER"}

    def execute(self, context):
        bpy.ops.mesh.looptools_space()
        bpy.ops.mesh.looptools_relax()
        
        return {"FINISHED"}
                

# -----------------------------------------------------------------------------
#    Auto Mirror
# -----------------------------------------------------------------------------  
bpy.types.Scene.AutoMirror_cut = bpy.props.BoolProperty(default= True, description="If enabeled, cut the mesh in two parts and mirror it. If not, just make a loopcut")
#Auto Mirror
class MeshAlignVertices(bpy.types.Operator):
    """  """
    bl_idname = "object.mesh_align_vertices"
    bl_label = "Align Vertices on 1 Axis"

    def execute(self, context):
        bpy.ops.object.mode_set(mode = 'OBJECT')

        x1,y1,z1 = bpy.context.scene.cursor_location
        bpy.ops.view3d.snap_cursor_to_selected()

        x2,y2,z2 = bpy.context.scene.cursor_location

        bpy.context.scene.cursor_location[0],bpy.context.scene.cursor_location[1],bpy.context.scene.cursor_location[2]  = 0,0,0

        #Vertices coordinate to 0 (local coordinate, so on the origin)
        for vert in bpy.context.object.data.vertices:
            if vert.select:
                axis = 0
                vert.co[axis] = 0

        bpy.context.scene.cursor_location = x2,y2,z2

        bpy.ops.object.origin_set(type='ORIGIN_CURSOR')

        bpy.context.scene.cursor_location = x1,y1,z1

        bpy.ops.object.mode_set(mode = 'EDIT')  
        return {'FINISHED'}

class MeshAutoMirror(bpy.types.Operator):
    """ Automatically cut an object along an axis """
    bl_idname = "object.mesh_automirror"
    bl_label = "AutoMirror"
    bl_options = {'REGISTER', 'UNDO'}

    
    def get_local_axis_vector(self, context, X, Y, Z, orientation):
        loc = context.object.location
        bpy.ops.object.mode_set(mode="OBJECT") # Needed to avoid to translate vertices
        
        v1 = Vector((loc[0],loc[1],loc[2]))
        bpy.ops.transform.translate(value=(X*orientation, Y*orientation, Z*orientation), constraint_axis=((X==1), (Y==1), (Z==1)), constraint_orientation='LOCAL')
        v2 = Vector((loc[0],loc[1],loc[2]))
        bpy.ops.transform.translate(value=(-X*orientation, -Y*orientation, -Z*orientation), constraint_axis=((X==1), (Y==1), (Z==1)), constraint_orientation='LOCAL')
        
        bpy.ops.object.mode_set(mode="EDIT")
        return v2-v1
    
    def execute(self, context):
        X,Y,Z = 0,0,0
        X = 1
        
        current_mode = bpy.context.object.mode # Save the current mode
        
        if bpy.context.object.mode != "EDIT":
            bpy.ops.object.mode_set(mode="EDIT") # Go to edit mode
        bpy.ops.mesh.select_all(action='SELECT') # Select all the vertices
        
        #Direction of the mirror
        orientation = 1
        cut_normal = self.get_local_axis_vector(context, X, Y, Z, orientation)
            
        bpy.ops.mesh.bisect(plane_co=(bpy.context.object.location[0], bpy.context.object.location[1], bpy.context.object.location[2]), plane_no=cut_normal, use_fill= False, clear_inner= bpy.context.scene.AutoMirror_cut, clear_outer= 0, threshold= 0.01) # Cut the mesh
        
        bpy.ops.object.mesh_align_vertices() # Use to align the vertices on the origin, needed by the "threshold"
        
        bpy.ops.object.mode_set(mode=current_mode) # Reload previous mode
        
        #Add mirror
        bpy.ops.object.modifier_add(type='MIRROR') # Add a mirror modifier
        bpy.context.object.modifiers["Mirror"].use_clip = True
        bpy.context.object.modifiers["Mirror"].use_mirror_merge = True
        bpy.context.object.modifiers["Mirror"].show_on_cage = True
        bpy.ops.object.modifier_move_up(modifier="Mirror")
        return {'FINISHED'}        
# -----------------------------------------------------------------------------
#    UI
# -----------------------------------------------------------------------------        

#Update Panels
def speedretopo_update_panel_position(self, context):
    try:
        bpy.utils.unregister_class(SpeedRetopoTools)
        bpy.utils.unregister_class(SpeedRetopoUI)
    except:
        pass
    
    try:
        bpy.utils.unregister_class(SpeedRetopoUI)
    except:
        pass
    
    if context.user_preferences.addons[__name__].preferences.speedretopo_tab_location == 'tools':
        SpeedRetopoTools.bl_category = context.user_preferences.addons[__name__].preferences.category
        bpy.utils.register_class(SpeedRetopoTools)
    
    else:
        bpy.utils.register_class(SpeedRetopoUI)

#Tools    
class SpeedRetopoTools(bpy.types.Panel):
    bl_idname = "speed_retopo"
    bl_label = "SpeedRetopo"
    bl_space_type = "VIEW_3D"
    bl_region_type = "TOOLS"
    bl_category = "category"
    
    def draw(self, context):
        layout = self.layout
        WM = context.window_manager
        SpeedRetopo(self, context)

# UI                 
class SpeedRetopoUI(bpy.types.Panel):
    bl_label = "SpeedRetopo"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    
    def draw(self, context):
        layout = self.layout
        WM = context.window_manager
        SpeedRetopo(self, context)


#Panel
def SpeedRetopo(self, context):
    layout = self.layout
    WM = context.window_manager
    obj = context.active_object
    
    if context.object is not None :
        layout.label("Reference Object:")
        row= layout.row()
        sub = row.row(align=True)
        sub.scale_x = 3.5
        sub.prop_search(WM, "ref_obj", bpy.data, 'objects', text="")
        shrinkwrap = bpy.context.active_object.modifiers.get("Shrinkwrap")
    
    #Object
    if context.object is not None and bpy.context.object.mode == "OBJECT": 
        row= layout.row(align=True)
        row.scale_y = 1.5   
        row.operator("object.create_speed_retopo", text="Setup Retopo", icon='MOD_TRIANGULATE')
        
    if context.object is not None and bpy.context.object.mode == "EDIT":  
        if "mesh_bsurfaces" in bpy.context.user_preferences.addons:
            row= layout.row(align=True)
            row.scale_y = 1.5
            row.scale_x = 1
            row.operator("gpencil.surfsk_add_surface", text="Add BSurface", icon='MOD_DYNAMICPAINT') 
            row.scale_x = 1.5
            row.operator("wm.context_toggle", text="", icon="ORTHO").data_path = "space_data.use_occlude_geometry"
            row.operator("object.align2x", text="", icon='MOD_WIREFRAME') 
            if hasattr(bpy.types, "MESH_OT_retopomt"):
#            if "Retopo_MT" in bpy.context.user_preferences.addons:
                row = layout.row(align=True)
                row.scale_y = 1.5 
                row.operator("mesh.retopomt", icon='VPAINT_HLT')
            
        else :
            row= layout.row()
            row.label("Activate Bsurface", icon='ERROR') 
            row.scale_x = 2
            row.operator("screen.userpref_show",text="", icon='PREFERENCES') 

        if shrinkwrap :
            sub.operator("apply.shrinkwrap", text="", icon = 'X') 
        else:  
            sub.operator("object.add_shrinkwrap", text="", icon = 'MOD_SHRINKWRAP')   
    
    
    #Edit
    if context.object is not None and bpy.context.object.mode == "EDIT":  
        mirror = bpy.context.active_object.modifiers.get("Mirror")
        if mirror :
            row= layout.row(align=True)
            row.scale_y = 1.5
            row.scale_x = 1.2
            row.prop(bpy.context.active_object.modifiers["Mirror"], "show_viewport", text="Hide Mirror") 
            row.prop(bpy.context.active_object.modifiers["Mirror"], "use_clip", text="", icon='UV_EDGESEL') 
            row.operator("apply.mirror", text="", icon='FILE_TICK') 
            row.operator("object.remove_mirror", text="", icon='X') 
            
        else:
            row = layout.row(align=True)
            row.scale_y = 1.5
            row.operator("object.mesh_automirror", text="Add Mirror", icon = 'MOD_MIRROR')

                             
        
        if "mesh_looptools" in bpy.context.user_preferences.addons:
            
            split = layout.split()
            col = split.column(align=True)
            row = col.row(align=True)
            row.scale_y = 1.5 
            row.operator("mesh.looptools_gstretch", text="GStretch", icon = 'LINE_DATA') 
            row.operator("object.space_relax", text="Space", icon = 'ALIGN')
            row = col.row(align=True)
            row.scale_y = 1.5 
            row.operator("mesh.looptools_bridge", text="Bridge", icon = 'MOD_LATTICE') 
            row.operator("mesh.fill_grid", text="Grid Fill", icon = 'OUTLINER_DATA_LATTICE')
        else:
            split = layout.split()
            col = split.column(align=True)
            row = col.row(align=True)
            row.label("Activate Looptools", icon='ERROR') 
            row.scale_x = 2
            row.operator("screen.userpref_show",text="", icon='PREFERENCES') 
            
        row = col.row(align=True)
        row.scale_y = 1.5 
        row.operator("mesh.speed_retopo_relax", text="Relax", icon = 'OUTLINER_OB_LATTICE') 
        
        
        
            
            
# Pie Menu                
class SpeedRetopoPieMenu(bpy.types.Menu):
    bl_idname = "view3d.speed_retopo_pie_menu"
    bl_label = "SpeedRetopo Pie Menu"

    def draw(self, context):
        pie = self.layout.menu_pie()
        WM = context.window_manager
        obj = context.active_object
        
        #Object
        if context.object is not None and bpy.context.object.mode == "OBJECT": 
            
            #4 - LEFT
            pie.separator()
            
            #6 - RIGHT
            pie.separator()
            
            #2 - BOTTOM
            pie.separator()
            
            #8 - TOP
            pie.operator("object.create_speed_retopo", text="Setup Retopo", icon='MOD_TRIANGULATE')
            
            #7 - TOP - LEFT 
            pie.prop_search(WM, "ref_obj", bpy.data, 'objects', text="")         
            
            #9 - TOP - RIGHT
            pie.separator()
            
            #1 - BOTTOM - LEFT
            pie.separator()
            
            #3 - BOTTOM - RIGHT
            pie.separator()
        
        
        #Edit
        if context.object is not None and bpy.context.object.mode == "EDIT":  
            #4 - LEFT
            mirror = bpy.context.active_object.modifiers.get("Mirror")
            if mirror :
                col = pie.column(align=True)
                row=col.row(align=True)
                row.scale_y = 1.3
                row.scale_x = 0.8 
                row.prop(bpy.context.active_object.modifiers["Mirror"], "show_viewport", text="Hide Mirror") 
                row.scale_x = 1.2
                row.prop(bpy.context.active_object.modifiers["Mirror"], "use_clip", text="", icon='UV_EDGESEL') 
                row=col.row(align=True)
                row.scale_y = 1.3
                row.scale_x = 1.1
                row.operator("apply.mirror", text="Apply") 
                row.operator("object.remove_mirror", text="Remove") 
            else:
                pie.operator("object.mesh_automirror", text="Add Mirror", icon = 'MOD_MIRROR')
        
        
            #6 - RIGHT
            pie.operator("object.align2x", text="Align to X", icon='MOD_WIREFRAME') 
            
                    
            #2 - BOTTOM
            if hasattr(bpy.types, "MESH_OT_retopomt"):
#            if "Retopo_MT" in bpy.context.user_preferences.addons:
                pie.operator("mesh.retopomt", icon='VPAINT_HLT')
            
            else:
                if "mesh_looptools" in bpy.context.user_preferences.addons:
                    pie.operator("mesh.fill_grid", text="Grid Fill", icon = 'OUTLINER_DATA_LATTICE')
                else:
                    row= pie.row()
                    row.label("Activate Looptools", icon='ERROR') 
                
            #8 - TOP
            if "mesh_bsurfaces" in bpy.context.user_preferences.addons:
                pie.operator("gpencil.surfsk_add_surface", text="Add BSurface", icon='MOD_DYNAMICPAINT') 
            else :
                row= pie.row()
                row.label("Activate Bsurface", icon='ERROR') 
            
            #7 - TOP - LEFT 
            col = pie.column(align=True)
            row=col.row(align=True)
            row.prop_search(WM, "ref_obj", bpy.data, 'objects', text="")
            
            shrinkwrap = bpy.context.active_object.modifiers.get("Shrinkwrap")
            if shrinkwrap :
                row=col.row(align=True)
                row.scale_y = 1.3
                row.scale_x = 1.1
                row.operator("apply.shrinkwrap", text="Remove shrinkwrap", icon = 'X') 
            else: 
                row=col.row(align=True) 
                row.scale_y = 1.3
                row.operator("object.add_shrinkwrap", text="Add shrinkwrap", icon = 'MOD_SHRINKWRAP')           
            
            #9 - TOP - RIGHT
            if "mesh_looptools" in bpy.context.user_preferences.addons:
                pie.operator("object.space_relax", text="Space", icon = 'ALIGN')
            else:
                row= pie.row()
                row.label("Activate Looptools", icon='ERROR') 
            
            #1 - BOTTOM - LEFT
            if "mesh_looptools" in bpy.context.user_preferences.addons:
                split = pie.split()
                col = split.column(align=True)
                if hasattr(bpy.types, "MESH_OT_retopomt"):
#                if "Retopo_MT" in bpy.context.user_preferences.addons:
                    row = col.row(align=True)
                    row.scale_y = 1.3
                    row.scale_x = 1.5 
                    row.operator("mesh.fill_grid", text="Grid Fill", icon = 'OUTLINER_DATA_LATTICE')
                
                row = col.row(align=True)
                row.scale_y = 1.3
                row.scale_x = 1.5 
                row.operator("mesh.looptools_gstretch", text="GStretch", icon = 'LINE_DATA')
                row = col.row(align=True)
                row.scale_y = 1.3
                row.scale_x = 1.5
                row.operator("mesh.looptools_bridge", text="Bridge", icon = 'MOD_LATTICE') 
            else:
                row= pie.row()
                row.label("Activate Looptools", icon='ERROR') 
            
            #3 - BOTTOM - RIGHT
            pie.operator("mesh.speed_retopo_relax", text="Relax", icon = 'OUTLINER_OB_LATTICE') 



                            
# Preferences            
class AddonPreferences(bpy.types.AddonPreferences):
    bl_idname = __name__
    
            
    prefs_tabs = EnumProperty(
        items=(('info', "Info", "Info"),
               ('links', "Links", "Links")),
               default='info'
               )
                      
    category = bpy.props.StringProperty(
            name="Category",
            description="Choose a name for the category of the panel",
            default="Tools",
            update=speedretopo_update_panel_position) 
    
    use_pie_menu = BoolProperty(
            default=True
            )
            
    #Tab Location           
    speedretopo_tab_location = EnumProperty(
        name = 'Panel Location',
        description = 'The 3D view shelf to use. (Save user settings and restart Blender)',
        items=(('tools', 'Tool Shelf', 'Places the Asset Management panel in the tool shelf'),
               ('ui', 'Property Shelf', 'Places the Asset Management panel in the property shelf.')),
               default='tools',
               update = speedretopo_update_panel_position,
               )
                                    
    def draw(self, context):
            layout = self.layout
            wm = bpy.context.window_manager
            
            
            row= layout.row(align=True)
            row.prop(self, "prefs_tabs", expand=True)
            if self.prefs_tabs == 'info':
                layout = self.layout
                
                box = layout.box()
                box.label("Panel Location: ")
                
                row= box.row(align=True)
                row.prop(self, 'speedretopo_tab_location', expand=True)
                row = box.row()
                if self.speedretopo_tab_location == 'tools':
                    split = box.split()
                    col = split.column()
                    col.label(text="Change Category:")
                    col = split.column(align=True)
                    col.prop(self, "category", text="") 
                
                row= box.row(align=True)
#                row.label("Use Pie Menu: ")
                row.prop(self, 'use_pie_menu', expand=True)
                
                
                    
                layout.label("Informations :")   
                layout.label("Welcome to SpeedRetopo, this addon allows you to create fast retopologies")   
                layout.label("To use is, activate Bsurface, Looptools and Automirror") 
                
            if self.prefs_tabs == 'links':  
                layout.operator("wm.url_open", text="Asset Management").url = "https://gumroad.com/l/kANV"
                layout.operator("wm.url_open", text="Speedflow").url = "https://gumroad.com/l/speedflow"
                layout.operator("wm.url_open", text="SpeedSculpt").url = "https://gumroad.com/l/SpeedSculpt"
                layout.separator() 
                layout.operator("wm.url_open", text="Pitiwazou.com").url = "http://www.pitiwazou.com/"
                layout.operator("wm.url_open", text="Wazou's Ghitub").url = "https://github.com/pitiwazou/Scripts-Blender"
                layout.operator("wm.url_open", text="BlenderLounge Forum").url = "http://blenderlounge.fr/forum/"           



#Register 
addon_keymaps = []  
          
def register():
    bpy.utils.register_module(__name__)
    
    speedretopo_update_panel_position(None, bpy.context)
    
    wm = bpy.context.window_manager
    
    if wm.keyconfigs.addon:
        
        #Retopo
        km = wm.keyconfigs.addon.keymaps.new(name = '3D View Generic', space_type = 'VIEW_3D')
        addon = bpy.context.window_manager.keyconfigs.addon
        if bpy.context.user_preferences.addons[__name__].preferences.use_pie_menu :
            
            kmi = km.keymap_items.new('wm.call_menu_pie', 'RIGHTMOUSE', 'PRESS', shift=True)
            kmi.properties.name = "view3d.speed_retopo_pie_menu"    

        addon_keymaps.append(km)

def unregister():
    bpy.utils.unregister_module(__name__)
    
    wm = bpy.context.window_manager

    if wm.keyconfigs.addon:
        for km in addon_keymaps:
            for kmi in km.keymap_items:
                km.keymap_items.remove(kmi)

            wm.keyconfigs.addon.keymaps.remove(km)

    # clear the list
    del addon_keymaps[:]   

if __name__ == "__main__":
    register()
            