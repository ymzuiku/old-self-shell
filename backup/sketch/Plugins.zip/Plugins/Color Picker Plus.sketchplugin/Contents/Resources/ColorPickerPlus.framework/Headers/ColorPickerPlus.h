//
//  ColorPickerPlus.h
//  ColorPickerPlus
//
//  Created by Andrey on 10/17/15.
//  Copyright © 2015 Turbobabr. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for ColorPickerPlus.
FOUNDATION_EXPORT double ColorPickerPlusVersionNumber;

//! Project version string for ColorPickerPlus.
FOUNDATION_EXPORT const unsigned char ColorPickerPlusVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ColorPickerPlus/PublicHeader.h>


