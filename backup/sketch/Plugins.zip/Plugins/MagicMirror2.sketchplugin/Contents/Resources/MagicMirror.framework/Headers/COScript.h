//
//  COScript_h
//  MagicMirror2
//
//  Created by James Tang on 7/12/2015.
//  Copyright © 2015 James Tang. All rights reserved.
//

#ifndef COScript_h
#define COScript_h

#import <Foundation/Foundation.h>

@protocol COScript <NSObject>

@property (nonatomic) BOOL shouldKeepAround;

@end

#endif /* COScript_h */
