//
//  CDUnknownBlockType.h
//  MagicMirror2
//
//  Created by James Tang on 8/12/2015.
//  Copyright © 2015 James Tang. All rights reserved.
//

#ifndef CDUnknownBlockType_h
#define CDUnknownBlockType_h

typedef void(^CDUnknownBlockType)(void);

#endif /* CDUnknownBlockType_h */
